---
title: Ridgerunner
isbn: '9788293326861'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/861/326/9788293326861.jpg'
---


Rusty Barnes grew up in rural northern Appalachia. He received his BA from Mansfield University of Pennsylvania and his MFA from Emerson College. His fiction, poetry, and nonfiction have appeared in over 150 journals and anthologies. After editing fiction for the Beacon Street Review (now Redivider) and Zoetrope All-Story Extra, he co-founded Night Train, a literary journal that has been featured in the Boston Globe, the New York Times, and on National Public Radio. Sunnyoutside Press published a collection of his flash fiction, Breaking It Down, in November 2007. MiPOesias published his poetry chapbook Redneck Poems in October 2010.