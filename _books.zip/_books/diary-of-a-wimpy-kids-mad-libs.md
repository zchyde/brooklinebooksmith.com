---
title: Diary of a Wimpy Kids Mad Libs
isbn: '9780843183535'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/535/183/9780843183535.jpg'
---

