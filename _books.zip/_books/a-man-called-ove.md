---
title: A Man Called Ove
isbn: '9781476738024'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/024/738/9781476738024.jpg'
---

