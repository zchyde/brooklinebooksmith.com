---
title: 'Tetris: The Games People Play'
isbn: '9781626723153'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/153/723/9781626723153.jpg'
---


