---
title: The BFG
isbn: '9780142410387'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/387/410/9780142410387.jpg'
---


