---
title: The Princess in Black
isbn: '9780763678883'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/883/678/9780763678883.jpg'
---


Who says princesses don t wear black? When trouble raises its blue monster head, Princess Magnolia ditches her flouncy dresses and becomes the Princess in Black Princess Magnolia is having hot chocolate and scones with Duchess Wigtower when . . . "Brring Brring "The monster alarm A big blue monster is threatening the goats Stopping monsters is no job for dainty Princess Magnolia. But luckily Princess Magnolia has a secret she's also the Princess in Black, and stopping monsters is the perfect job for "her" Can the princess sneak away, transform into her alter ego, and defeat the monster before the nosy duchess discovers her secret? From award-winning writing team of Shannon and Dean Hale and illustrator LeUyen Pham, here is the first in a humorous and action-packed chapter book series for young readers who like their princesses not only prim and perfect, but also dressed in black.