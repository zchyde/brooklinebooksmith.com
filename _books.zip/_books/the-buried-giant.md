---
title: The Buried Giant
isbn: '9780307455796'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/796/455/9780307455796.jpg'
---

