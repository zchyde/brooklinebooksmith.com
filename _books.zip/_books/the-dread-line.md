---
title: The Dread Line
isbn: '9780765374332'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/332/374/9780765374332.jpg'
---


The Dread Line: the latest Liam Mulligan novel from award winning author Bruce DeSilva.

Since he got fired in spectacular fashion from his newspaper job last year, former investigative reporter Liam Mulligan has been piecing together a new life--one that straddles both sides of the law. He's getting some part-time work with his friend McCracken's detective agency. He's picking up beer money by freelancing for a local news website. And he's looking after his semi-retired mobster-friend's bookmaking business.

But Mulligan still manages to find trouble. He's feuding with a cat that keeps leaving its kills on his porch. He's obsessed with a baffling jewelry heist. And he's enraged that someone in town is torturing animals. All this keeps distracting him from a big case that needs his full attention. The New England Patriots, shaken by a series of murder charges against a star player, have hired Mulligan and McCracken to investigate the background of a college athlete they're thinking of drafting. At first, the job seems routine, but as soon as they begin asking questions, they get push-back. The player, it seems, has something to hide--and someone is willing to kill to make sure it remains secret.