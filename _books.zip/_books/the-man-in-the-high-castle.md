---
title: The Man in the High Castle
isbn: '9780547572482'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/482/572/9780547572482.jpg'
---

