---
title: Sticker Dolly Dressing Ice Skaters
isbn: '9780794530693'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/693/530/9780794530693.jpg'
---

