---
title: The Future Tense of Joy
isbn: '9781580055697'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/697/055/9781580055697.jpg'
---


