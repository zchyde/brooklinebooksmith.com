---
title: 'The Muralist: A Novel'
isbn: '9781616203573'
link_to_buy_page:
image_path: 'https://images.booksense.com/images/573/203/9781616203573.jpg'
thumbnail_height: '500'
thumbnail_width: '330'
url: 'https://www.amazon.com/The-Muralist-B-A-Shapiro/dp/1616203579'
---


