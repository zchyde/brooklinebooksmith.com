---
title: 'The Last Star: The Final Book of the 5th Wave'
isbn: '9780399162435'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/435/162/9780399162435.jpg'
---


