---
title: 'Finding Fontainebleau: An American Boy in France'
isbn: '9780525428800'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/800/428/9780525428800.jpg'
---


The son of an air force officer, Thad Carhart grew up in a variety of places, including Washington, D.C.; Fontainebleau, France; Minneapolis; and Tokyo. After graduating from Yale, he worked for the State Department as an interpreter. He is the author of The Piano Shop on the Left Bank and Across the Endless River.