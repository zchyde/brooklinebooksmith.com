---
title: Outline
isbn: '9781250081544'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/544/081/9781250081544.jpg'
---

