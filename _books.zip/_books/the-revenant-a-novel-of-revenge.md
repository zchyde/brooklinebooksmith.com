---
title: 'The Revenant: A Novel of Revenge'
isbn: '9781250072689'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/689/072/9781250072689.jpg'
---

