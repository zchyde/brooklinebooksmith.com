---
title: The Marvelous Magic of Miss Mabel
isbn: '9781481465335'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/335/465/9781481465335.jpg'
---


Wild fantasy, sly satire, and sharply observed family dynamics are the hallmarks of this tasty, effervescent series (along with mouthwatering recipes); this volume's the most delectable yet. Kirkus Reviews&nbsp;
<br>Penderwicks meets Edward Eager in this charming coming of age tale about a young witch found in a flowerpot who's on a journey to discover her roots.&nbsp;
<br>The morning Nora Ratcliff finds a baby in the flowerpot on her front steps her life changes forever. She had always wanted a child, but after her husband passed away, Nora never thought she would have one, but her flowerpot child was a miracle and she decided to name her Mabel. As Mabel grew up, she showed a distinct talent for magic.&nbsp;
<br>When Mabel is accepted to the prestigious witch school, Ruthersfield Academy, she excels at the magic curriculum but is constantly in trouble for experimenting and inventing her own potions. One day she is asked to write a paper on her magical roots and discovers the truth about her birth after a mean classmate blurts out what everyone seems to know except Mabel. Mabel is shocked but the revelation does explain a lot. In rebellion, Mabel changes her name to Magnolia and tries to understand why she was left in the flowerpot and who her birth family might be.&nbsp;
<br>Will Mabel find the answers she's looking for or will she discover that families are people who love each other and look after each other and that's most important of all.