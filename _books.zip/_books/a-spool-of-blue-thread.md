---
title: A Spool of Blue Thread
isbn: '9780553394399'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/399/394/9780553394399.jpg'
---


"NEW YORK TIMES" BESTSELLER - SHORTLISTED FOR THE MAN BOOKER PRIZE -NAMED ONE OF THE TEN BEST BOOKS OF THE YEAR BY "PEOPLE" AND""USA TODAY"" -NAMEDONE OF THE BEST BOOKS OF THE YEAR BY "The Washington Post "NPR "Chicago Tribune St. Louis Post-Dispatch The Telegraph BookPage"&nbsp;
<br>"Look for special features inside. Join the Random House Reader's Circle for author chats and more. "&nbsp;
<br>It was a beautiful, breezy, yellow-and-green afternoon. . . . This is how Abby Whitshank always describes the day she fell in love with Red in July 1959. The Whitshanks are one of those families that radiate an indefinable kind of specialness, but like all families, their stories reveal only part of the picture: Abby and Red and their four grown children have accumulated not only tender moments, laughter, and celebrations, but also jealousies, disappointments, and carefully guarded secrets. From Red's parents, newly arrived in Baltimore in the 1920s, to the grandchildren carrying the Whitshank legacy boisterously into the twenty-first century, here are four generations of lives unfolding in and around the sprawling, lovingly worn house that has always been their anchor.&nbsp;
<br>Praise for "A Spool of Blue Thread"&nbsp;
<br>An act of literary enchantment . . . Anne] Tyler remains among the best chroniclers of family life this country has ever produced. "The Washington Post
<br>"
<br>Quintessential Anne Tyler, as well as quintessential American comedy . . . She] has a knack for turning sitcom situations into something far deeper and more moving. "The New York Times Book Review"&nbsp;
<br>By my count I ve now reviewed around fifty books for "USA Today." I ve never given any of them four stars until today: to "A Spool of Blue Thread, " the masterful twentieth novel by Anne Tyler. "USA Today
<br>"
<br>By the end of this deeply beguiling novel, we come to know a reality entirely different from the one at the start. "O: The Oprah Magazine"&nbsp;
<br>Well-crafted, utterly absorbing and compelling . . . probably the best novel you will read all year. "Chicago Tribune"&nbsp;
<br>A miracle of sorts . . . tender, touching and funny . . . an] understated masterpiece. Associated Press&nbsp;
<br>Exploring the] dichotomy the imperfections that reside within a polished exterior is Tyler's specialty, and her latest generation-spanning work accomplishes just that, masterfully and monumentally. "Elle"&nbsp;
<br>The story of any family is told through the prism of time. And no storyteller compares to Tyler when it comes to unspooling those tales. "St. Louis Post-Dispatch"&nbsp;
<br>Vintage Anne Tyler . . . The Whitshanks are] rendered with such immediacy and texture that they might be our next-door neighbors. "Los Angeles Times"&nbsp;
<br>The magic of Tyler's novels is that] youimagine these characters carrying on, muddling through, enduring the necessary sorrows and quiet joys of their lives somewhere beyond the page. " The Seattle Times"&nbsp;
<br>The sort of novel that's hard to disentangle yourself from. Warm, charming and emotionally radiant, it surely must be counted as among Tyler's best. "The Miami Herald"&nbsp;
<br>Prose so polished it practically glows on the page. " Houston Chronicle.