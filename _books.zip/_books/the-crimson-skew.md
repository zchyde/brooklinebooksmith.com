---
title: The Crimson Skew
isbn: '9780670785049'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/049/785/9780670785049.jpg'
---


