---
title: "Fat City"
isbn: "9781590178928"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/511iRopUviL.jpg"
thumbnail_height: "500"
thumbnail_width: "313"
url: "https://www.amazon.com/City-York-Review-Books-Classics/dp/1590178920"
---
