---
title: Roses and Rot
isbn: '9781481451161'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/161/451/9781481451161.jpg'
---


