---
title: 'The Myth of the Spoiled Child: Coddled Kids, Helicopter Parents, and Other Phony Crises'
isbn: '9780807073889'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/889/073/9780807073889.jpg'
---

