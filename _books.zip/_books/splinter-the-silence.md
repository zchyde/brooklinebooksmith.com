---
title: Splinter the Silence
isbn: '9780802124081'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/081/124/9780802124081.jpg'
---

