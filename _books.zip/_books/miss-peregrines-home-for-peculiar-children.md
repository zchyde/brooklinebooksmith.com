---
title: "Miss Peregrine's Home for Peculiar Children"
isbn: '9781594746031'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/031/746/9781594746031.jpg'
---


