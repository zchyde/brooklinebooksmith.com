---
title: Brighton
isbn: '9780062442970'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/970/442/9780062442970.jpg'
---


The f\*\*king bomb I loved it. Stephen King

A gritty and suspenseful Boston thriller for fans of Dennis Lehane and The Departed

An extraordinary thriller gripping, haunting, and marvelously told about two friends growing up in a rapidly changing Boston, who must face the sins of their past in the midst of a series of brutal murders.

You came back here to bury your past. . . . Thing is, you gotta kill it first.

Kevin Pearce baseball star, honor student, the pride of Brighton was fifteen when he left town in the back of his uncle's cab. He and his buddy Bobby Scales had just committed heinous violence for what they thought were the best of reasons. Kevin didn t want a pass, but he was getting it anyway. Bobby would stay and face the music; Kevin's future would remain bright as ever. At least that was the way things were supposed to work, except in Brighton things never work the way they re supposed to.

Twenty-six years later, Kevin is a Pulitzer Prize winning journalist for theBoston Globe. He's never been back to his old block, having avoided his family and, especially, Bobby Scales. Then he learns his old friend is the prime suspect in a string of local murders. Suddenly, Kevin's headed home to protect a friend and the secret they share. To report this story to the end and protect those he loves, he must face not only an elusive, slippery killer, but his own corrupted conscience.

A powerhouse of a thriller, Brightonis a riveting and elegiac exploration of promises broken, debts owed, and old wrongs made right . . . no matter what the cost.