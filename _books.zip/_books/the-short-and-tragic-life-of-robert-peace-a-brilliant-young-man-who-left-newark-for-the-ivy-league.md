---
title: 'The Short and Tragic Life of Robert Peace: A Brilliant Young Man Who Left Newark for the Ivy League'
isbn: '9781476731919'
binding: Hardcover
link_to_buy_page:
image_path:
---


