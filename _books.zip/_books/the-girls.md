---
title: The Girls
isbn: '9780812998603'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/603/998/9780812998603.jpg'
---


