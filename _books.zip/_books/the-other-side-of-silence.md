---
title: The Other Side of Silence
isbn: '9780399177040'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/040/177/9780399177040.jpg'
---


Philip Kerr, a former advertising copywriter, is the bestselling author of more than twenty books, including the Bernie Gunther series and several stand-alone thrillers. In 2009, Philip won the Ellis Peters Historical Award and Spain's RBA International Prize for Crime Writing. He divides his time between London and Cornwall, England.