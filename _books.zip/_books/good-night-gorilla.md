---
title: 'Good Night, Gorilla'
isbn: '9780399230035'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/035/230/9780399230035.jpg'
---

