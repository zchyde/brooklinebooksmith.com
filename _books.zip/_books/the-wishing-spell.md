---
title: The Wishing Spell
isbn: '9780316201568'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/568/201/9780316201568.jpg'
---

