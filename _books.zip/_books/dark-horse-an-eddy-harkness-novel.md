---
title: 'Dark Horse: An Eddy Harkness Novel'
isbn: '9780544253247'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/247/253/9780544253247.jpg'
---


