---
title: The Sellout
isbn: '9780374260507'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/507/260/9780374260507.jpg'
---

