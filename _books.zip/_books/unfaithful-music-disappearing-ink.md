---
title: "Unfaithful Music &amp; Disappearing Ink"
isbn: "9780399167256"
binding: Hardcover
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/51I3xtBR3EL.jpg"
thumbnail_height: "500"
thumbnail_width: "340"
url: "https://www.amazon.com/Unfaithful-Music-Disappearing-Elvis-Costello/dp/0399167250"
---

