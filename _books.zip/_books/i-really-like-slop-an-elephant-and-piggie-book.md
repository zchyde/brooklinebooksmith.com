---
title: 'I Really Like Slop! (an Elephant and Piggie Book)'
isbn: '9781484722626'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/626/722/9781484722626.jpg'
---

