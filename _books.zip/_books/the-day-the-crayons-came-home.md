---
title: "The Day the Crayon's Came Home"
isbn: '9780399172755'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/755/172/9780399172755.jpg'
---

