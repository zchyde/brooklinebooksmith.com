---
title: 'Known and Strange Things: Essays'
isbn: '9780812989786'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/786/989/9780812989786.jpg'
---


