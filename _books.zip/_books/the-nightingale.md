---
title: The Nightingale
isbn: '9780312577223'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/223/577/9780312577223.jpg'
---

