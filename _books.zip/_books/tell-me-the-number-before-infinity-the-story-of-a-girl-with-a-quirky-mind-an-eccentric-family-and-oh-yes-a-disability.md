---
title: 'Tell Me the Number Before Infinity: The Story of a Girl with a Quirky Mind, an Eccentric Family, and Oh Yes, a Disability'
isbn: '9780977307081'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/081/307/9780977307081.jpg'
---


