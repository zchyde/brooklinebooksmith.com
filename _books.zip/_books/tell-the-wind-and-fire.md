---
title: Tell the Wind and Fire
isbn: '9780544318175'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/175/318/9780544318175.jpg'
---


Sarah Rees Brennanwriteswith fine control and wit, andI suspect that word of this magical thriller will pass through the populace with the energy of wind, of fire. Gregory Maguire, author of "Wicked" and "Egg and Spoon"&nbsp;
In a city divided between opulent luxury in the Light and fierce privations in the Dark, a determined young woman survives by guarding her secrets.&nbsp;
Lucie Manette was born in the Dark half of the city, but careful manipulations won her a home in the Light, celebrity status, and a rich, loving boyfriend. Now she just wants to keep her head down, but her boyfriend has a dark secret of his own one involving an apparent stranger who is destitute and despised. Lucie alone knows the young men's deadly connection, and even as the knowledge leads her to make a grave mistake, she can trust no one with the truth.&nbsp;
Blood and secrets alike spill out when revolution erupts. With both halves of the city burning, and mercy nowhere to be found, can Lucie save either boy or herself?&nbsp;
Celebrated author Sarah Rees Brennan weaves a magical tale of romance and revolution, love and loss.