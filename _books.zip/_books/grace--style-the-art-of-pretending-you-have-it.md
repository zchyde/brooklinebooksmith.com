---
title: 'Grace & Style: The Art of Pretending You Have It'
isbn: '9781501120589'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/589/120/9781501120589.jpg'
---

