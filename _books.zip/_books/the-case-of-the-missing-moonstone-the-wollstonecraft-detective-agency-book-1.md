---
title: 'The Case of the Missing Moonstone (the Wollstonecraft Detective Agency, Book 1)'
isbn: '9780385754439'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/439/754/9780385754439.jpg'
---


