---
title: The Glass Sentence
isbn: '9780142423660'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/660/423/9780142423660.jpg'
---


