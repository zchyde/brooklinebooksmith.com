---
title: "Navel Gazing: True Tales of Bodies, Mostly Mine (But Also My Mom's, Which I Know Sounds Weird)"
isbn: '9781476748825'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/825/748/9781476748825.jpg'
---

