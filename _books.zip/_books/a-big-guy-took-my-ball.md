---
title: 'A Big Guy Took My Ball!'
isbn: '9781423174912'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/912/174/9781423174912.jpg'
---


