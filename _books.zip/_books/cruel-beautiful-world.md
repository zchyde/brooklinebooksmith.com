---
title: Cruel Beautiful World
isbn: '9781616203634'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/634/203/9781616203634.jpg'
---


