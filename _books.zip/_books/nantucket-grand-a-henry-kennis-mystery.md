---
title: 'Nantucket Grand: A Henry Kennis Mystery'
isbn: '9781464205538'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/538/205/9781464205538.jpg'
---


