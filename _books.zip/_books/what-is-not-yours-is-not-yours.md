---
title: What Is Not Yours Is Not Yours
isbn: '9781594634635'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/635/634/9781594634635.jpg'
---


“There is magic in Helen Oyeyemi's writing. There is magic in the settings, which shift between the conventional and the fantastic as readers devotedly follow her characters down any path they please. There is magic in the tales themselves, as readers recognize a situation only to have it bloom into a flower they have never imagined before, full of beauty or of dread. And, most certainly, there is magic in such breathtaking prose and unimaginable characters. This is a captivating story collection, filled with both fairy tale whimsy and dark, complicated mystery. Highly recommended!”&nbsp;
— Luisa Smith, Book Passage, Corte Madera, CA