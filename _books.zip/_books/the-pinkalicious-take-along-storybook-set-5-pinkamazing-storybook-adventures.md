---
title: 'The Pinkalicious Take-Along Storybook Set: 5 Pinkamazing Storybook Adventures'
isbn: '9780062410801'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/801/410/9780062410801.jpg'
---

