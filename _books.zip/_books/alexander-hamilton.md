---
title: Alexander Hamilton
isbn: '9780143034759'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/759/034/9780143034759.jpg'
---

