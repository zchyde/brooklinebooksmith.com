---
title: The Story of a New Name
isbn: '9781609451349'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/349/451/9781609451349.jpg'
---

