---
title: The Haters
isbn: '9781419720789'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/789/720/9781419720789.jpg'
---


From Jesse Andrews, author of the "New York Times" bestselling "Me and Earl and the Dying Girl "and screenwriter of the Sundance award winning motion picture of the same name, comes a groundbreaking young adult novel about music, love, friendship, and freedom as three young musicians follow a quest to escape the law long enough to play the amazing show they hope (but also doubt) they have in them.&nbsp;
Inspired by the years he spent playing bass in a band himself, "The Haters" is Jesse Andrews's road trip adventure about a trio of jazz-camp escapees who, against every realistic expectation, become a band.&nbsp;
For Wes and his best friend, Corey, jazz camp turns out to be lame. It's pretty much all dudes talking in Jazz Voice. But then they jam with Ash, a charismatic girl with an unusual sound, and the three just click. It's three and a half hours of pure musical magic, and Ash makes a decision: They need to hit the road. Because the road, not summer camp, is where bands get good. Before Wes and Corey know it, they re in Ash's SUV heading south, and The Haters Summer of Hate Tour has begun.&nbsp;
In his second novel, Andrews again brings his brilliant and distinctive voice to YA, in the perfect book for music lovers, fans of "The Commitments" (author Rody Doyle raves ""The Haters" is terrific.It is shocking and funny, unsettling and charming."" ), " and "High Fidelity," or anyone who has ever loved and hated a song or a band. This witty, funny coming-of-age novel is contemporary fiction at its best.