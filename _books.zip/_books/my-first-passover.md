---
title: My First Passover
isbn: '9780448447919'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/919/447/9780448447919.jpg'
---


Passover is a time for families and friends to celebrate their faith and shared history. Tomie dePaola's simple text and beautiful illustrations provide insight into this special holiday for young readers.