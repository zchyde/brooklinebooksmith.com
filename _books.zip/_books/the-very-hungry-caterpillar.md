---
title: The Very Hungry Caterpillar
isbn: '9780399226908'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/908/226/9780399226908.jpg'
---

