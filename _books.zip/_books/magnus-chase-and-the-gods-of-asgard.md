---
title: 'Magnus Chase and the Gods of Asgard, Book One: The Sword of Summer'
isbn: '9781423160915'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/915/160/9781423160915.jpg'
---

