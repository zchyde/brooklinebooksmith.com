---
title: The Little Paris Bookshop pb
isbn: '9780553418798'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/798/418/9780553418798.jpg'
---


