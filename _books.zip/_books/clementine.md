---
title: Clementine
isbn: '9780786838837'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/837/838/9780786838837.jpg'
---

