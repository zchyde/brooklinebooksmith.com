---
title: 'Standoff: Poems'
isbn: '9781555977450'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/450/977/9781555977450.jpg'
---


