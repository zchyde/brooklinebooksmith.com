---
title: 'I Will Take a Nap!'
isbn: '9781484716304'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/304/716/9781484716304.jpg'
---

