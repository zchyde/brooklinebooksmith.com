---
title: 'The Sorcerer’s Daughter: The Defenders of Shannara'
isbn: '9780345540829'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/718/190/9780804190718.jpg'
---


