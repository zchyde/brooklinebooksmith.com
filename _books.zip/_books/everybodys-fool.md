---
title: "Everybody's Fool"
isbn: '9780307270641'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/641/270/9780307270641.jpg'
---


A best-selling and beloved author, at the very top of his game, now returns to North Bath, in upstate New York, and the characters who made "Nobody's Fool, " his third novel, his first great success.&nbsp;
<br>The irresistible Sully, who in the intervening years has come by some unexpected good fortune, is now staring down a VA cardiologist's estimate that he only has a year or two left, and he's busy as hell keeping the news from the most important people in his life: Ruth, the married woman he carried on with for years... the ultra-hapless Rub Squeers, who worries that he and Sully aren't still best friends... Sully's son and grandson, for whom he was mostly an absentee figure... Doug Raymer, now chief of police and still obsessing over the identity of the man his wife might have been having an affair with before she died in a freak accident... North Bath's mayor, the former academic Gus Moynihan, who also has a pressing wife problem... and then there's Carl Roebuck, whose lifelong run of failing upwards might now come to ruin. "Everybody's Fool "is filled with humor, heart, hard times, and characters whom you can't help but love for all their faults. It is classic Russo--and a crowning achievement from one of the greatest storytellers of our time.