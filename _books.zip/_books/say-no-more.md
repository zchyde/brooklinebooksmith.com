---
title: Say No More
isbn: '9780765385352'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/352/385/9780765385352.jpg'
---


"Say No More: "The Thrilling Next Installment in Hank Phillippi Ryan's Award-Winning Jane Ryland Series

When Boston reporter Jane Ryland reports a hit and run, she soon learns she saw more than a car crash she witnessed the collapse of an alibi. Working on an expose of sexual assaults on college campuses for the station's new documentary unit, Jane's just convinced a date rape victim to reveal her heartbreaking experience on camera. However, a disturbing anonymous message SAY NO MORE has Jane really and truly scared.

Homicide detective Jake Brogan is on the hunt for the murderer of Avery Morgan, a hot-shot Hollywood screenwriter. Her year as a college guest lecturer just ended at the bottom of her swimming pool in the tight-knit and tight-lipped Boston community called The Reserve. As Jake chips his way through a code of silence as shatterproof as any street gang, he ll learn that one newcomer to the neighborhood may have a secret of her own.

A young woman faces a life-changing decision should she go public about her assault? Jane and Jake now semi-secretly engaged and beginning to reveal their relationship to the world are both on a quest for answers as they try to balance the consequences of the truth.