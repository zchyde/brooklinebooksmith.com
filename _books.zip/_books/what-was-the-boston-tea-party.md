---
title: What Was the Boston Tea Party?
isbn: '9780448462882'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/882/462/9780448462882.jpg'
---


