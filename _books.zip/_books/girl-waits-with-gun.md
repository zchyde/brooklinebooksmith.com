---
title: Girl Waits with Gun
isbn: '9780544800830'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/830/800/9780544800830.jpg'
---


A National Bestseller
<br>ANew York TimesEditors' Choice
<br>A September 2015 Indie Next Pick
<br>A Publishers Marketplace Buzz Book of 2015, Fall/Winter
<br>One ofUSA Today's "New and Noteworthy"
<br>One ofNew York Post's "Must-Read" Books
<br>One ofCosmopolitan's "24 Books to Read this Fall"
<br>
<br>From the New York Times best-selling author of The Drunken Botanist comes an enthralling novel based on the forgotten true story of one of the nation's first female deputy sheriffs.
<br>
<br>Constance Kopp doesn t quite fit the mold. She towers over most men, has no interest in marriage or domestic affairs, and has been isolated from the world since a family secret sent her and her sisters into hiding fifteen years ago. One day a belligerent and powerful silk factory owner runs down their buggy, and a dispute over damages turns into a war of bricks, bullets, and threats as he unleashes his gang on their family farm. When the sheriff enlists her help in convicting the men, Constance is forced to confront her past and defend her family and she does it in a way that few women of 1914 would have dared. A smart, romping adventure, featuring some of the most memorable and powerful female characters I've seen in print for a long time. I loved every page as I followed the Kopp sisters through a too-good-to-be-true (but mostly true ) tale of violence, courage, stubbornness, and resourcefulness. Elizabeth Gilbert