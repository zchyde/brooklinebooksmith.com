---
title: Sarong Party Girls
isbn: '9780062448965'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/965/448/9780062448965.jpg'
---


