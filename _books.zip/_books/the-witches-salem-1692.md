---
title: 'The Witches: Salem, 1692'
isbn: '9780316200608'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/608/200/9780316200608.jpg'
---

