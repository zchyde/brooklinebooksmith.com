---
title: 13 Ways of Looking at a Fat Girl
isbn: '9780143128489'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/489/128/9780143128489.jpg'
---

