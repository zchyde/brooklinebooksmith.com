---
title: 'The Finest Hours (Young Readers Edition): The True Story of a Heroic Sea Rescue'
isbn: '9781250044235'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/235/044/9781250044235.jpg'
---


