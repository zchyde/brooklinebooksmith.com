---
title: "The Blind Angel"
isbn: "9781592643592"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/51Q0ddzpZ9L.jpg"
thumbnail_height: "500"
thumbnail_width: "323"
url: "https://www.amazon.com/Blind-Angel-Tovia-Halberstam/dp/1592643590/ref=tmm_hrd_swatch_0?_encoding=UTF8&amp;qid=1445870702&amp;sr=1-1"
---
