---
title: 'Brief Encounters: A Collection of Contemporary Nonfiction'
isbn: '9780393350999'
binding: Hardcover
link_to_buy_page:
image_path:
---
Writer and educator Judith Kitchen (1941 2014) was the cofounder of the Rainier Writing Workshop at Pacific Lutheran University.

Dinah Lenney teaches writing in the Bennington Writing Seminars, the Rainier Writing Workshop, and at the University of Southern California.