---
title: Smile
isbn: '9780545132060'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/060/132/9780545132060.jpg'
---


Raina Telgemeier's #1 "New York Times" bestselling, Eisner Award-winning graphic memoir based on her childhood&nbsp;
<br>Raina just wants to be a normal sixth grader. But one night after Girl Scouts she trips and falls, severely injuring her two front teeth. What follows is a long and frustrating journey with on-again, off-again braces, surgery, embarrassing headgear, and even a retainer with fake teeth attached. And on top of all that, there's still more to deal with: a major earthquake, boy confusion, and friends who turn out to be not so friendly.