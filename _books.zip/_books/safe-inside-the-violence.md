---
title: "Safe Inside the Violence"
isbn: "9788293326700"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/41Fm%2BZnUsNL.jpg"
thumbnail_height: "500"
thumbnail_width: "313"
url: "https://www.amazon.com/Safe-Inside-Violence-Christopher-Irvin/dp/8293326700/ref=tmm_pap_swatch_0?_encoding=UTF8&amp;qid=1445873544&amp;sr=1-1"
---
