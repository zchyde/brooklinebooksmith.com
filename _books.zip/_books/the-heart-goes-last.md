---
title: The Heart Goes Last
isbn: '9781101912362'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/362/912/9781101912362.jpg'
---


One of the Best Books of the Year: "The Boston Globe"&nbsp;
<br>Stan and Charmaine, a young urban couple, have been hit by job loss and bankruptcy in the midst of a nationwide economic collapse. Forced to live in their third-hand Honda, where they are vulnerable to roving gangs, they think the gated community of Consilience may be the answer to their prayers. If they sign a life contract, they ll get a job and a lovely house . . . for six months out of the year. On alternating months, residents must leave their homes and serve as inmates in the Positron prison system. At first, this seems worth it: they will have a roof over their heads and food on the table. But when a series of troubling events unfolds, Positron begins to look less like a prayer answered and more like a chilling prophecy fulfilled. "The Heart Goes Last" is a vivid, urgent vision of development and decay, freedom and surveillance, struggle and hope and the timeless workings of the human heart.