---
title: 'When Bunnies Go Bad: A Pru Marlowe Pet Noir'
isbn: '9781464205354'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/354/205/9781464205354.jpg'
---


