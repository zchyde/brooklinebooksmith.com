---
title: 'Black Panther, Book 1: A Nation Under Our Feet'
isbn: '9781302900533'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/533/900/9781302900533.jpg'
---


A new era begins for the Black Panther MacArthur Genius and National Book Award-winning writer T-Nehisi Coates (BETWEEN THE WORLD AND ME) takes the helm, confronting T'Challa with a dramatic upheaval in Wakanda that will make leading the African nation tougher than ever before. When a superhuman terrorist group that calls itself The People sparks a violent uprising, the land famed for its incredible technology and proud warrior traditions will be thrown into turmoil. If Wakanda is to survive, it must adapt--but can its monarch, one in a long line of Black Panthers, survive the necessary change? Heavy lies the head that wears the cowl&nbsp;