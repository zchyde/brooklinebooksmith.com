---
title: "Giraffes Can't Dance"
isbn: '9780545392556'
binding: Board Books
link_to_buy_page:
image_path: 'https://images.booksense.com/images/556/392/9780545392556.jpg'
---


Giraffes Can't Dance is a touching tale of Gerald the giraffe, who wants nothing more than to dance. With crooked knees and thin legs, it's harder for a giraffe than you would think. Gerald is finally able to dance to his own tune when he gets some encouraging words from an unlikely friend.

With light-footed rhymes and high-stepping illustrations, this tale is gentle inspiration for every child with dreams of greatness.