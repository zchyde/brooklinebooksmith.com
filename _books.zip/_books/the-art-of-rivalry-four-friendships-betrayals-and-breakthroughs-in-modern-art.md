---
title: 'The Art of Rivalry: Four Friendships, Betrayals, and Breakthroughs in Modern Art'
isbn: '9780812994803'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/803/994/9780812994803.jpg'
---


