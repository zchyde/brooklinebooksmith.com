---
title: "November 9: A Novel"
isbn: "9781501110344"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/51o%2B6%2BVPUGL.jpg"
thumbnail_height: "500"
thumbnail_width: "321"
url: "https://www.amazon.com/November-9-Novel-Colleen-Hoover/dp/1501110349"
---