---
title: "The Inquisitor's Tale: Or, the Three Magical Children and Their Holy Dog"
isbn: '9780525426165'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/165/426/9780525426165.jpg'
---


