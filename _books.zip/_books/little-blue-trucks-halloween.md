---
title: "Little Blue Truck's Halloween"
isbn: '9780544772533'
binding: Board Books
link_to_buy_page:
image_path: 'https://images.booksense.com/images/533/772/9780544772533.jpg'
---


