---
title: The Two-Family House
isbn: '9781250076922'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/922/076/9781250076922.jpg'
---


Lynda Cohen Loigman grew up in Longmeadow, MA. She received a B.A. in English and American Literature from Harvard College and a J.D. from Columbia Law School. She is now a student of the Writing Institute at Sarah Lawrence College, and lives with her husband and two children in Chappaqua, NY.