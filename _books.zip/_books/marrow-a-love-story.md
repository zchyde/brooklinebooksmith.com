---
title: 'Marrow: A Love Story'
isbn: '9780062367631'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/631/367/9780062367631.jpg'
---


