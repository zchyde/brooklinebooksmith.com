---
title: "The Girl in the Spider's Web: A Lisbeth Salander Novel, Continuing Stieg Larsson's Millennium Series"
isbn: '9781101872000'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/000/872/9781101872000.jpg'
---


