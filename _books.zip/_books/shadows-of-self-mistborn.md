---
title: "Shadows of Self (Mistborn)"
isbn: "9780765378552"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/51elU7hCehL.jpg"
thumbnail_height: "500"
thumbnail_width: "329"
url: "https://www.amazon.com/Shadows-Self-Mistborn-Brandon-Sanderson/dp/0765378558/ref=sr_1_fkmr0_1?s=books&amp;ie=UTF8&amp;qid=1444420257&amp;sr=1-1-fkmr0&amp;keywords=Brandon+Sanderson%2C+Shadows+of+Self%3A+A+Mistborn+Novel"
---