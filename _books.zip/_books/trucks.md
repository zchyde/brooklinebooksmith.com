---
title: Trucks
isbn: '9780312515829'
binding: Board Books
link_to_buy_page:
image_path: 'https://images.booksense.com/images/829/515/9780312515829.jpg'
---


