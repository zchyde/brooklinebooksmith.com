---
title: Rough Trade
isbn: '9781943818006'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/006/818/9781943818006.jpg'
---


