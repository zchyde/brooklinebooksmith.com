---
title: Night
isbn: '9780374500016'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/016/500/9780374500016.jpg'
---


