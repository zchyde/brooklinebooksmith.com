---
title: The Sound of Silence
isbn: '9780316203371'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/371/203/9780316203371.jpg'
---


