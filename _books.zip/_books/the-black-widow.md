---
title: The Black Widow
isbn: '9780062320223'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/223/320/9780062320223.jpg'
---


