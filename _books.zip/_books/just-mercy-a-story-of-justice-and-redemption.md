---
title: 'Just Mercy: A Story of Justice and Redemption'
isbn: '9780812984965'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/965/984/9780812984965.jpg'
---

