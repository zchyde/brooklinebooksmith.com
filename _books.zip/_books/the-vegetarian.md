---
title: The Vegetarian
isbn: '9781101906118'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/118/906/9781101906118.jpg'
---


