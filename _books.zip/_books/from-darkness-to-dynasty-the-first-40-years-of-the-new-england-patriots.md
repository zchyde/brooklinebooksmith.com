---
title: 'From Darkness to Dynasty: The First 40 Years of the New England Patriots'
isbn: '9781611689747'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/747/689/9781611689747.jpg'
---


