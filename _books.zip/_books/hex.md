---
title: Hex
isbn: '9780765378804'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/804/378/9780765378804.jpg'
---


