---
title: Sweetbitter
isbn: '9781101875940'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/940/875/9781101875940.jpg'
---


