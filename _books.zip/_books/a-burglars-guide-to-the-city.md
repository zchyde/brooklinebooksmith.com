---
title: "A Burglar's Guide to the City"
isbn: '9780374117269'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/269/117/9780374117269.jpg'
---


