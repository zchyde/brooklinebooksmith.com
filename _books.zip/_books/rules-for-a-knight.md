---
title: Rules for a Knight
isbn: '9780307962331'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/331/962/9780307962331.jpg'
---

