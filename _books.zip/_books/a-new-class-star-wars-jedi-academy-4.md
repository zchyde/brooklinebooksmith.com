---
title: 'A New Class (Star Wars: Jedi Academy #4)'
isbn: '9780545875738'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/738/875/9780545875738.jpg'
---


Victor Starspeeder is psyched to be starting school at the Jedi Academy. His sister, Christina does not share an enthusiasm for Victor's newfound educational path. She's horrified that her annoying baby brother will be there to cramp her style.&nbsp;
<br>While Victor means well, his excess energy leads him to spend a lot of time in detention with the little, green sage, Yoda. Yoda wants to channel Victor's talents, so he makes the young Padawan join the drama club. Victor is not pleased. "Learn to control your anger, you must Successfully manage their emotions, a good Jedi can. Box step and jazz hands ... hee hee ... young Padawan will "&nbsp;
<br>Victor will have to make new friends, get on his sister's good side, learn to use the force, and hope the year's drama club performance ("Wookie Side Story"? "Annie Get Your Lightsaber"?) goes off without a hitch.