---
title: Mercy Watson To the Rescue
isbn: '9780763645045'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/045/645/9780763645045.jpg'
---


