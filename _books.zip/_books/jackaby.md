---
title: Jackaby
isbn: '9781616205461'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/461/205/9781616205461.jpg'
---

