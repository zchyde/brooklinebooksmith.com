---
title: The Asset
isbn: '9781476796215'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/215/796/9781476796215.jpg'
---


