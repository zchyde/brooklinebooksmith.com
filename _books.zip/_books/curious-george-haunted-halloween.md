---
title: Curious George Haunted Halloween
isbn: '9780544320796'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/796/320/9780544320796.jpg'
---


