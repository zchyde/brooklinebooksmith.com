---
title: "Jewish Noir: Contemporary Tales of Crime and Other Dark Deeds"
isbn: "9781629631110"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/51nAJWgjdTL.jpg"
thumbnail_height: "500"
thumbnail_width: "333"
url: "https://www.amazon.com/Jewish-Noir-Contemporary-Tales-Crime/dp/1629631116"
---