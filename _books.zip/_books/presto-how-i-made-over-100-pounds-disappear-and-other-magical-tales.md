---
title: 'Presto!: How I Made Over 100 Pounds Disappear and Other Magical Tales'
isbn: '9781501140181'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/181/140/9781501140181.jpg'
---


