---
title: The Wolf of Sarajevo
isbn: '9780399175015'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/015/175/9780399175015.jpg'
---


