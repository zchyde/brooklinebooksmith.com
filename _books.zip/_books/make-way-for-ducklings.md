---
title: Make Way for Ducklings
isbn: '9780140564341'
isbn_pbk: '9780670451494'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/341/564/9780140564341.jpg'
---

