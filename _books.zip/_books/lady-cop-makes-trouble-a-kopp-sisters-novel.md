---
title: Lady Cop Makes Trouble (A Kopp Sisters Novel)
isbn: '9780544409941'
binding:
link_to_buy_page:
image_path: 'https://images.booksense.com/images/941/409/9780544409941.jpg'
---


