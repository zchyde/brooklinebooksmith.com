---
title: El Deafo
isbn: '9781419712173'
binding: Paperback
link_to_buy_page:
image_path: 'https://images.booksense.com/images/173/712/9781419712173.jpg'
---

