---
title: "The Point of Vanishing: A Memoir of Two Years in Solitude"
isbn: "9780807075463"
link_to_buy_page:
image_path: "https://ecx.images-amazon.com/images/I/61G6YLzKwxL.jpg"
thumbnail_height: "500"
thumbnail_width: "324"
url: "https://www.amazon.com/The-Point-Vanishing-Memoir-Solitude/dp/0807075469"
---
