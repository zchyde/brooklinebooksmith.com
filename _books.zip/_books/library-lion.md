---
title: Library Lion
isbn: '9780763637842'
binding: Hardcover
link_to_buy_page:
image_path: 'https://images.booksense.com/images/842/637/9780763637842.jpg'
---


