---
title: Running Out of Time
isbn: '9780689812361'
binding: Hardcover
image_path: 'https://images.booksense.com/images/361/812/9780689812361.jpg'
---


Jessie lives with her family in the frontier village of Clifton, Indiana, in 1840 -- or so she believes. When diphtheria strikes the village and the children of Clifton start dying, Jessie's mother reveals a shocking secret -- it's actually 1996, and they are living in a reconstructed village that serves as a tourist site. In the world outside, medicine exists that can cure the dread disease, and Jessie's mother is sending her on a dangerous mission to bring back help.&nbsp;
But beyond the walls of Clifton, Jessie discovers a world even more alien and threatening than she could have imagined, and soon she finds her own life in jeopardy. Can she get help before the children of Clifton, and Jessie herself, run out of time?