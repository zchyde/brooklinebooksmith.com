---
title: The Raven King
isbn: '9780545424981'
binding: Hardcover
image_path: 'https://images.booksense.com/images/981/424/9780545424981.jpg'
---


All her life, Blue has been warned that she will cause her true love's death. She doesn't believe in true love and never thought this would be a problem, but as her life becomes caught up in the strange and sinister world of the Raven Boys, she's not so sure anymore.

In a starred review for "Blue Lily, Lily Blue," "Kirkus Reviews" declared: "Expect this truly one-of-a-kind series to come to a thundering close.