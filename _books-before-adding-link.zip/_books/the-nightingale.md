---
title: The Nightingale
isbn: '9780312577223'
binding: Hardcover
image_path: 'https://images.booksense.com/images/223/577/9780312577223.jpg'
---

