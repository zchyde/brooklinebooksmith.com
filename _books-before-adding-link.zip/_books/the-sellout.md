---
title: The Sellout
isbn: '9780374260507'
binding: Hardcover
image_path: 'https://images.booksense.com/images/507/260/9780374260507.jpg'
---

