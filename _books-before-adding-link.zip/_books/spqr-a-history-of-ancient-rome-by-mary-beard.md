---
title: 'Spqr: A History of Ancient Rome: By Mary Beard - Summary & Highlights'
isbn: '9781519558947'
binding: Paperback
image_path: 'https://images.booksense.com/images/947/558/9781519558947.jpg'
---

