---
title: 'Shh! We Have a Plan'
isbn: '9780763679774'
binding: Hardcover
image_path: 'https://images.booksense.com/images/774/679/9780763679774.jpg'
---


