---
title: Outline
isbn: '9781250081544'
binding: Paperback
image_path: 'https://images.booksense.com/images/544/081/9781250081544.jpg'
---

