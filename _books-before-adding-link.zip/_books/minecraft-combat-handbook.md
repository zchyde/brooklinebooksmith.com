---
title: 'Minecraft: Combat Handbook'
isbn: '9780545823234'
binding: Hardcover
image_path: 'https://images.booksense.com/images/234/823/9780545823234.jpg'
---


Revised edition with the most up to date stats, info, and sixteen pages of brand-new material&nbsp;
<br>In Minecraft, you're never alone and the threat of attack is constant. How will you survive? The Official Combat Handbook now has sixteen additional pages with brand-new content. This book will teach you everything you need to know to defend yourself from hostile monsters and enemy players. You can learn how to build a fort, craft armor and weapons, set mob traps, defeat your enemies in one-on-one combat, and battle your way out of the Nether and the End. With tips from Minecraft experts, developer Jeb, and creator Notch himself, you'll be a Minecraft warrior in no time.