---
title: 'Elephant and Friends: A Soft and Fuzzy Book for Baby'
isbn: '9781438005270'
binding: Board Books
image_path: 'https://images.booksense.com/images/270/005/9781438005270.jpg'
---

