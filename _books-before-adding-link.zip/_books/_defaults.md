---
title:
available:
isbn:
binding:
image_path:
link:
---
