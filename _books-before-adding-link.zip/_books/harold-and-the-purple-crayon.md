---
title: Harold and the Purple Crayon
isbn: '9780064430227'
binding: Hardcover
image_path: 'https://images.booksense.com/images/227/430/9780064430227.jpg'
---


