---
title: 'Dylan Goes, Electric!: Newport, Seeger, Dylan, and the Night That Split the Sixties'
isbn: '9780062366689'
binding: Hardcover
image_path: 'https://images.booksense.com/images/689/366/9780062366689.jpg'
---


