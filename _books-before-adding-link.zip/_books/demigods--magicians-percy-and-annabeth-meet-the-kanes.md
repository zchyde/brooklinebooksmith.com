---
title: 'Demigods & Magicians: Percy and Annabeth Meet the Kanes'
isbn: '9781484732786'
binding: Hardcover
image_path: 'https://images.booksense.com/images/786/732/9781484732786.jpg'
---


Magic, monsters, and mayhem abound when Percy Jackson and Annabeth Chase meet Carter and Sadie Kane for the first time. Weird creatures are appearing in unexpected places, and the demigods and magicians have to team up to take them down. As they battle with Celestial Bronze and glowing hieroglyphs, the four heroes find that they have a lot in common--and more power than they ever thought possible. But will their combined forces be enough to foil an ancient enemy who is mixing Greek and Egyptian incantations for an evil purpose? Rick Riordan wields his usual storytelling magic in this adrenaline-fueled adventure.