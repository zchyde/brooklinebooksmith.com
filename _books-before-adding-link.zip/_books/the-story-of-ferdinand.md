---
title: The Story of Ferdinand
isbn: '9780140502343'
binding: Hardcover
image_path: 'https://images.booksense.com/images/343/502/9780140502343.jpg'
---


