---
title: The Princess in Black and the Hungry Bunny Horde
isbn: '9780763665135'
binding: Hardcover
image_path: 'https://images.booksense.com/images/135/665/9780763665135.jpg'
---

