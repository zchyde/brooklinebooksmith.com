---
title: 'Standoff: Poems'
isbn: '9781555977450'
binding:
image_path: 'https://images.booksense.com/images/450/977/9781555977450.jpg'
---


