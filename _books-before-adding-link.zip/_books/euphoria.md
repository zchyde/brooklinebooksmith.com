---
title: Euphoria
isbn: '9780802123701'
binding: Hardcover
image_path: 'https://images.booksense.com/images/701/123/9780802123701.jpg'
---

