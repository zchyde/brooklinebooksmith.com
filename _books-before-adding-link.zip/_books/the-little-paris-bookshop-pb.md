---
title: The Little Paris Bookshop pb
isbn: '9780553418798'
binding:
image_path: 'https://images.booksense.com/images/798/418/9780553418798.jpg'
---


