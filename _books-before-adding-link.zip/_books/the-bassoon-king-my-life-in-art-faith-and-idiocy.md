---
title: "The Bassoon King: My Life in Art, Faith, and Idiocy"
isbn: "9780525954538"
thumbnail_height: "500"
thumbnail_width: "332"
url: "https://www.amazon.com/The-Bassoon-King-Faith-Idiocy/dp/0525954538"
---