---
title: 'The Pinkalicious Take-Along Storybook Set: 5 Pinkamazing Storybook Adventures'
isbn: '9780062410801'
binding: Hardcover
image_path: 'https://images.booksense.com/images/801/410/9780062410801.jpg'
---

