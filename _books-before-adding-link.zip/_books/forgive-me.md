---
title: Forgive Me
isbn: '9780758293473'
binding: Hardcover
image_path: 'https://images.booksense.com/images/473/293/9780758293473.jpg'
---


In a heart-pounding thriller from one of the most innovative voices in contemporary suspense, a woman unravels the shocking truth about her parents, her past, and a life built upon an unthinkable lie.&nbsp;
<br>AtDeRose & Associates Private Investigators in Virginia, Angie DeRose strives to find and rescue endangered runaways--work that stands in stark contrast to her own safe, idyllic childhood. But in the wake of her mother's sudden death, Angie makes a life-altering discovery. Hidden among the mementos in her parents' attic is a photograph of a little girl, with a code and a hand-written message on the back: "May God forgive me."&nbsp;
<br>Angie has no idea what it means or how to explain other questionable items among her mother's possessions. Her father claims to know nothing. Could Angie have a sister or other relative she was never told about? Bryce Taggart, the US Marshal working with her agency, agrees to help Angie learn the fate of the girl in the photograph. But the lies she and Bryce unearth will bring her past and present together with terrifying force. And everything she cherishes will be threatened by the repercussions of one long-ago choice--and an enemy who will kill to keep a secret hidden forever.&nbsp;
<br>&nbsp;