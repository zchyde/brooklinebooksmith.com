---
title: Blueberries for Sal
isbn: '9780140501698'
binding: Hardcover
image_path: 'https://images.booksense.com/images/698/501/9780140501698.jpg'
---


What happens when Sal and her mother meet a mother bear and her cub? ACaldecott Honor Book&nbsp;
<br>"Kuplink, kuplank, kuplunk " Sal and her mother a picking blueberries to can for the winter. But when Sal wanders to the other side of Blueberry Hill, she discovers a mama bear preparing for her own long winter. Meanwhile Sal's mother is being followed by a small bear with a big appetite for berries Will each mother go home with the right little one?&nbsp;
<br>With its expressive line drawings and charming story, "Blueberries for Sal" has won readers' hearts since its first publication in 1948.