---
title: Little Blue Truck Board Book
isbn: '9780544568037'
binding: Hardcover
image_path: 'https://images.booksense.com/images/037/568/9780544568037.jpg'
---

