---
title: Black Wave
isbn: '9781558619395'
binding: Paperback
image_path: 'https://images.booksense.com/images/395/619/9781558619395.jpg'
---


Desperate to quell her addiction to drugs, disastrous romance, and nineties San Francisco, Michelle heads south for LA. But soon it's officially announced that the world will end in one year, and life in the sprawling metropolis becomes increasingly weird.&nbsp;
<br>While living in an abandoned bookstore, dating Matt Dillon, and keeping an eye on the encroaching apocalypse, Michelle begins a new novel, a sprawling and meta-textual exploration to complement her promises of maturity and responsibility. But as she tries to make queer love and art without succumbing to self-destructive vice, the boundaries between storytelling and everyday living begin to blur, and Michelle wonders how much she'll have to compromise her artistic process if she's going to properly ride out doomsday.