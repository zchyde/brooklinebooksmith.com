---
title: The Second Life of Nick Mason
isbn: '9780399574320'
binding: Hardcover
image_path: 'https://images.booksense.com/images/320/574/9780399574320.jpg'
---


Steve Hamilton was born and raised in Detroit, and graduated from the University of Michigan where he won the prestigious Hopwood Award for fiction. In 2006, he won the Michigan Author Award for his outstanding body of work. His novels have won numerous awards and media acclaim beginning with the very first in the Alex McKnight series, A Cold Day in Paradise, which won the Private Eye Writers of America/St. Martin's Press Award for Best First Mystery by an Unpublished Writer. Once published, it went on to win the MWA Edgar and the PWA Shamus Awards for Best First Novel, and was short-listed for the Anthony and Barry Awards. His book The Lock Artist is the winner of the 2011 Edgar Award for Best Novel. Hamilton currently works for IBM in upstate New York where he lives with his wife Julia and their two children.