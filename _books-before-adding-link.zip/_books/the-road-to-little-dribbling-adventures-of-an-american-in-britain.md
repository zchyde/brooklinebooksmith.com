---
title: 'The Road to Little Dribbling: Adventures of an American in Britain'
isbn: '9780385539289'
binding: Hardcover
image_path: 'https://images.booksense.com/images/289/539/9780385539289.jpg'
---

