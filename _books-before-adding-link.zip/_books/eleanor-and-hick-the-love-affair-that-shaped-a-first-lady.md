---
title: 'Eleanor and Hick: The Love Affair That Shaped a First Lady'
isbn: '9781594205408'
binding:
image_path: 'https://images.booksense.com/images/408/205/9781594205408.jpg'
---


