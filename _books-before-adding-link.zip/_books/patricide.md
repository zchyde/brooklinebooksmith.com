---
title: Patricide
isbn: '9780997062908'
binding: Hardcover
image_path: 'https://images.booksense.com/images/908/062/9780997062908.jpg'
---


