---
title: 'Crooked Kingdom: A Sequel to Six of Crows'
isbn: '9781627792134'
binding: Hardcover
image_path: 'https://images.booksense.com/images/134/792/9781627792134.jpg'
---


