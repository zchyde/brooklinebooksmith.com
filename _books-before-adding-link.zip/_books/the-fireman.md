---
title: The Fireman
isbn: '9780062200631'
binding: Hardcover
image_path: 'https://images.booksense.com/images/631/200/9780062200631.jpg'
---


