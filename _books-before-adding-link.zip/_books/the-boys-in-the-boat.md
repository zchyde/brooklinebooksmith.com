---
title: 'The Boys in the Boat: Nine Americans and Their Epic Quest for Gold at the 1936 Berlin Olympics'
isbn: '9780143125471'
binding: Paperback
image_path: 'https://images.booksense.com/images/471/125/9780143125471.jpg'
---

