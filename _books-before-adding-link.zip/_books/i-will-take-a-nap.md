---
title: 'I Will Take a Nap!'
isbn: '9781484716304'
binding: Hardcover
image_path: 'https://images.booksense.com/images/304/716/9781484716304.jpg'
---

