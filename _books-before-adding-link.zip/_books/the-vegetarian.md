---
title: The Vegetarian
isbn: '9781101906118'
binding: Paperback
image_path: 'https://images.booksense.com/images/118/906/9781101906118.jpg'
---


