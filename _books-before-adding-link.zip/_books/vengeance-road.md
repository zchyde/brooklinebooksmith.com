---
title: Vengeance Road
isbn: '9780544466388'
binding: Hardcover
image_path: 'https://images.booksense.com/images/388/466/9780544466388.jpg'
---


When Kate Thompson's father is killed by the notorious Rose Riders for a mysterious journal that reveals the secret location of a gold mine, the eighteen-year-old disguises herself as a boy and takes to the gritty plains looking for answers and justice. What she finds are devious strangers, dust storms, and a pair of brothers who refuse to quit riding in her shadow. But as Kate gets closer to the secrets about her family, she gets closer to the truth about herself and must decide if there's room for love in a heart so full of hate. In the spirit of "True Grit," the cutthroat days of the Wild West come to life for a new generation.