---
title: 'Petty: The Biography'
isbn: '9780805099683'
image_path: 'https://images.booksense.com/images/683/099/9780805099683.jpg'
thumbnail_height: ''
thumbnail_width: ''
url: ''
---

