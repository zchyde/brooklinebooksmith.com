---
title: 'Night Work: A Michael Cassidy Novel'
isbn: '9780765374851'
binding: Hardcover
image_path: 'https://images.booksense.com/images/851/374/9780765374851.jpg'
---


Night Work: the second book in David C. Taylor's transporting historical crime fiction series.

Michael Cassidy, a New York cop plagued by dreams that sometimes come true, escorts a prisoner accused of murder to Havana on the cusp of Fidel Castro's successful revolution against the Batista dictatorship. After delivering the man to La Cabana prison and rescuing Dylan McCue, a Russian KGB agent and his now-married former lover, from her scheduled execution, Cassidy returns to New York and retreats into the comforts of alcohol and sex.

The arrival of Fidel Castro in New York three months later complicates the cop's life once more. Cassidy's investigation of a young man's murder in Central Park is interrupted when he is assigned to Castro's protective detail.

Castro has many enemies. American mobsters who have been run out of Havana, businessmen who worry about their investments in Cuba, and members of Batista's secret police all want him dead. Cassidy is already investigating one murder. Can he prevent another?