---
title: Clementine
isbn: '9780786838837'
binding: Hardcover
image_path: 'https://images.booksense.com/images/837/838/9780786838837.jpg'
---

