---
title: The Crimson Skew
isbn: '9780670785049'
binding:
image_path: 'https://images.booksense.com/images/049/785/9780670785049.jpg'
---


