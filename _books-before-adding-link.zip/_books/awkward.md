---
title: Awkward
isbn: '9780316381307'
binding: Paperback
image_path: 'https://images.booksense.com/images/307/381/9780316381307.jpg'
---


Cardinal rule #1 for surviving school: Don't get noticed by the mean kids.
<br>Cardinal rule #2 for surviving school: Seek out groups with similar interests and join them.
<br>On her first day at her new school, Penelope--Peppi--Torres reminds herself of these basics. But when she trips into a quiet boy in the hall, Jaime Thompson, she's already broken the first rule, and the mean kids start calling her the "nerder girlfriend." How does she handle this crisis? By shoving poor Jaime and running away&nbsp;
<br>Falling back on rule two and surrounding herself with new friends in the art club, Peppi still can't help feeling ashamed about the way she treated Jaime. Things are already awkward enough between the two, but to make matters worse, he's a member of her own club's archrivals--the science club And when the two clubs go to war, Peppi realizes that sometimes you have to break the rules to survive middle school.