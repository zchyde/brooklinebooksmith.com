---
title: 'Dark Horse: An Eddy Harkness Novel'
isbn: '9780544253247'
binding:
image_path: 'https://images.booksense.com/images/247/253/9780544253247.jpg'
---


