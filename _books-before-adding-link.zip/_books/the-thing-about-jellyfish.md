---
title: The Thing about Jellyfish
isbn: '9780316380867'
binding: Hardcover
image_path: 'https://images.booksense.com/images/867/380/9780316380867.jpg'
---


