---
title: The Last Days of Magic
isbn: '9780525429531'
binding: Hardcover
image_path: 'https://images.booksense.com/images/531/429/9780525429531.jpg'
---

