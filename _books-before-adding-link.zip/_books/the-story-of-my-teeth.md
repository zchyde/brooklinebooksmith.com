---
title: "The Story of My Teeth"
isbn: "9781566894098"
image_path: "https://i.gr-assets.com/images/S/photo.goodreads.com/books/1429098006i/24796231._UY475_SS475_.jpg"
thumbnail_height: "475"
thumbnail_width: "475"
url: "https://www.goodreads.com/book/show/24796231-the-story-of-my-teeth"
cover_image_path: "/webhook-uploads/1443584316433_24796231._UY475_SS475_.jpg"
---

