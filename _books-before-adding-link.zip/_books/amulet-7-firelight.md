---
title: 'Amulet 7: Firelight'
isbn: '9780545433167'
binding: Hardcover
image_path: 'https://images.booksense.com/images/167/433/9780545433167.jpg'
---

