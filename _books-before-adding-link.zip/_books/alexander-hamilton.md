---
title: Alexander Hamilton
isbn: '9780143034759'
binding: Paperback
image_path: 'https://images.booksense.com/images/759/034/9780143034759.jpg'
---

