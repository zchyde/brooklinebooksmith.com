---
title: We Were Kings
isbn: '9780316323536'
binding: Hardcover
image_path: 'https://images.booksense.com/images/536/323/9780316323536.jpg'
---


n 1950's Boston, the Irish Republican Army is running guns and killing witnesses. Cal and Dante are committed to stopping them.
<br>When a body is discovered at the Charlestown locks--tarred, feathered and shot to death--it appears to be a gangland killing, and is almost immediately dismissed. However, Cal O'Brien's cousin, Boston PD detective Owen Lackey, recognizes the murder style as the typical retribution for IRA informers. Combined with a tip-off about a boat coming into Boston weighed down with stolen guns and ammunition, the body in the locks hints that much more may be at stake than a one-off hit.
<br>"Serpents in the Cold" introduced us to Cal and Dante, whose previous investigation brought them to the highest ranks of Boston's political elite. This time, Cal and Dante descend into the city's shadowy underbelly--a world of packed dance halls, Irish wakes, and funeral parlors. There they discover a terrorist plot that will shake the city to its core and bring them head-to-head not only with Cal's past, but with the IRA Army Council itself.