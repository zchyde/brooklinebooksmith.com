---
title: "Tonight the Streets Are Ours"
isbn: "9780374376659"
image_path: "https://i.gr-assets.com/images/S/photo.goodreads.com/books/1416414664i/23310761._UY475_SS475_.jpg"
thumbnail_height: "475"
thumbnail_width: "475"
url: "https://www.goodreads.com/book/show/23310761-tonight-the-streets-are-ours"
cover_image_path: "/webhook-uploads/1443584387618_23310761._UY475_SS475_.jpg"
---

