---
title: Library Lion
isbn: '9780763637842'
binding: Hardcover
image_path: 'https://images.booksense.com/images/842/637/9780763637842.jpg'
---


