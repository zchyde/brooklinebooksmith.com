---
title: 'Goodnight, Beautiful Women'
isbn: '9780802124845'
binding: Hardcover
image_path: 'https://images.booksense.com/images/845/124/9780802124845.jpg'
---


