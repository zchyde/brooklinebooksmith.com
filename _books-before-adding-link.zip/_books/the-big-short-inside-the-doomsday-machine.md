---
title: 'The Big Short: Inside the Doomsday Machine'
isbn: '9780393353150'
binding: Paperback
image_path: 'https://images.booksense.com/images/150/353/9780393353150.jpg'
---

