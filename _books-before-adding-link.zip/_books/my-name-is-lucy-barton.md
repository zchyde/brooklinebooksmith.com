---
title: My Name Is Lucy Barton
isbn: '9781400067695'
binding: Hardcover
image_path: 'https://images.booksense.com/images/695/067/9781400067695.jpg'
---

