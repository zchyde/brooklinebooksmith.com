---
title: 'The Best Advice in Six Words: Writers Famous and Obscure on Love, Sex, Money, Friendship, Family, Work, and Much More'
isbn: '9781250067012'
binding: Hardcover
image_path: 'https://images.booksense.com/images/012/067/9781250067012.jpg'
---

