---
title: Cruel Beautiful World
isbn: '9781616203634'
binding:
image_path: 'https://images.booksense.com/images/634/203/9781616203634.jpg'
---


