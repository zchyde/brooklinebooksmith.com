---
title: Bad Feminist
isbn: '9780062282712'
binding: Paperback
image_path: 'https://images.booksense.com/images/712/282/9780062282712.jpg'
---

