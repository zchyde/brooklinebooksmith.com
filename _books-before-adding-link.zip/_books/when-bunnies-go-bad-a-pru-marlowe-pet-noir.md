---
title: 'When Bunnies Go Bad: A Pru Marlowe Pet Noir'
isbn: '9781464205354'
binding: Paperback
image_path: 'https://images.booksense.com/images/354/205/9781464205354.jpg'
---


