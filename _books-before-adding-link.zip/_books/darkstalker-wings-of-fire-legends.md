---
title: 'Darkstalker (Wings of Fire: Legends)'
isbn: '9781338053616'
binding:
image_path: 'https://images.booksense.com/images/616/053/9781338053616.jpg'
---


