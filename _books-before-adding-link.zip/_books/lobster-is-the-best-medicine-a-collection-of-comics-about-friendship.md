---
title: 'Lobster Is the Best Medicine: A Collection of Comics about Friendship'
isbn: '9780762458684'
binding: Hardcover
image_path: 'https://images.booksense.com/images/684/458/9780762458684.jpg'
---


Fans have fallen in love with Liz Climo's charmingly quirky animal kingdom, which was first featured in "The Little World of Liz Climo"a place where porcupines, anteaters, and grizzly bears all grapple with everyday life with wit and humor. Now Liz returns with a book devoted to friendship. Chapter themes include Old Friends, New Friends, Unlikely Friends, and Friends with Benefits. It's the perfect gift for a special friend.