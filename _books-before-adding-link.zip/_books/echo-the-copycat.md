---
title: Echo the Copycat
isbn: '9781481450010'
binding: Hardcover
image_path: 'https://images.booksense.com/images/010/450/9781481450010.jpg'
---


In this nineteenth Goddess Girls adventure a new forest-mountain nymph shows up at Mount Olympus Academy and tries to fit.&nbsp;
<br>Echo is a forest-mountain nymph and the new girl at Mount Olympus Academy. She is a little nervous, so she tries to mimic all of the gestures, expressions, and slang of the cool MOA students. While imitation is supposed to be the best form of flattery, Echo's chattiness doesn t exactly endear her to her fellow classmates in fact, it has the opposite effect Will she be able to find a way to be herself and become friends with the students around her?