---
title: "The Princess in Black and the Perfect Princess Party"
isbn: "9780763665111"
image_path: "https://ecx.images-amazon.com/images/I/61i0uuziIUL.jpg"
thumbnail_height: "500"
thumbnail_width: "391"
url: "https://www.amazon.com/The-Princess-Black-Perfect-Party/dp/0763665118"
---

