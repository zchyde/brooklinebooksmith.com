---
title: The Moth
isbn: '9781401311117'
binding: Paperback
image_path: 'https://images.booksense.com/images/117/311/9781401311117.jpg'
---

