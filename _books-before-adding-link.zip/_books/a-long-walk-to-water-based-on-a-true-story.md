---
title: 'A Long Walk to Water: Based on a True Story'
isbn: '9780547577319'
binding: Hardcover
image_path: 'https://images.booksense.com/images/319/577/9780547577319.jpg'
---


