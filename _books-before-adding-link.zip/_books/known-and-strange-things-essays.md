---
title: 'Known and Strange Things: Essays'
isbn: '9780812989786'
binding:
image_path: 'https://images.booksense.com/images/786/989/9780812989786.jpg'
---


