---
title: The Wishing Spell
isbn: '9780316201568'
binding: Hardcover
image_path: 'https://images.booksense.com/images/568/201/9780316201568.jpg'
---

