---
title: "Georgia: A Novel of Georgia O'Keeffe"
isbn: '9781400069538'
binding: Hardcover
image_path: 'https://images.booksense.com/images/538/069/9781400069538.jpg'
---

