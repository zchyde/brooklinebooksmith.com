---
title: 'Rise of the Rocket Girls: The Women Who Propelled Us, from Missiles to the Moon to Mars'
isbn: '9780316338929'
binding: Hardcover
image_path: 'https://images.booksense.com/images/929/338/9780316338929.jpg'
---


