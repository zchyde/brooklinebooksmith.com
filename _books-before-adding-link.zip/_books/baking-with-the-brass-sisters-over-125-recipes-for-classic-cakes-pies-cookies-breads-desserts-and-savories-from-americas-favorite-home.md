---
title: "Baking with the Brass Sisters: Over 125 Recipes for Classic Cakes, Pies, Cookies, Breads, Desserts, and Savories from America&#39;s Favorite Home "
isbn: "9781250064356"
image_path: "https://ecx.images-amazon.com/images/I/61mJVykUCvL.jpg"
thumbnail_height: "500"
thumbnail_width: "412"
url: "https://www.amazon.com/Baking-Brass-Sisters-Desserts-Savories/dp/125006435X"
---
