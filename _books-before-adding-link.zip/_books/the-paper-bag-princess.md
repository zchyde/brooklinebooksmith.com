---
title: The Paper Bag Princess
isbn: '9780920236161'
binding: Paperback
image_path: 'https://images.booksense.com/images/161/236/9780920236161.jpg'
---

