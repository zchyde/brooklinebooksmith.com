---
title: The Mirror King
isbn: '9780062317414'
binding: Hardcover
image_path: 'https://images.booksense.com/images/414/317/9780062317414.jpg'
---


****

In this stunning conclusion to The Orphan Queen, Jodi Meadows follows Wilhelmina's breathtaking and brave journey from orphaned criminal on the streets to magic-wielding queen. This epic fantasy duology is perfect for fans of Graceling by Kristin Cashore, The Girl of Fire and Thorns by Rae Carson, and Shadow and Bone by Leigh Bardugo.

Princess Wilhelmina is ready for her crown, but declaring herself queen means war. Her magic is uncontrollable and now there's a living boy made of wraith destructive and deadly, and willing to do anything for her.

Caught between what she wants and what is right, Wilhelmina realizes the throne might not even matter. Everyone thought the wraith was years off, but already it's destroying Indigo Kingdom villages. Princess Wilhelmina's ability might be just the thing to help reclaim her kingdom or ruin it forever.