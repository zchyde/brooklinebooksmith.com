---
title: Roller Girl
isbn: '9780803740167'
binding: Paperback
image_path: 'https://images.booksense.com/images/167/740/9780803740167.jpg'
---

