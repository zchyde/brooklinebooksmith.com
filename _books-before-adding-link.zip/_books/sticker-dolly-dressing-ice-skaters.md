---
title: Sticker Dolly Dressing Ice Skaters
isbn: '9780794530693'
binding: Paperback
image_path: 'https://images.booksense.com/images/693/530/9780794530693.jpg'
---

