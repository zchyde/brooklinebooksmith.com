---
title: 'The Trials of Apollo, Book One: The Hidden Oracle'
isbn: '9781484732748'
binding: Hardcover
image_path: 'https://images.booksense.com/images/748/732/9781484732748.jpg'
---


How do you punish an immortal?&nbsp;
<br>By making him human.&nbsp;
<br>After angering his father Zeus, the god Apollo is cast down from Olympus. Weak and disoriented, he lands in New York City as a regular teenage boy. Now, without his godly powers, the four-thousand-year-old deity must learn to survive in the modern world until he can somehow find a way to regain Zeus's favor.&nbsp;
<br>But Apollo has many enemies-gods, monsters, and mortals who would love to see the former Olympian permanently destroyed. Apollo needs help, and he can think of only one place to go . . . an enclave of modern demigods known as Camp Half-Blood.