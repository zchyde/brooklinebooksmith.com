---
title: 'Thing Explainer: Complicated Stuff in Simple Words'
isbn: '9780544668256'
binding: Hardcover
image_path: 'https://images.booksense.com/images/256/668/9780544668256.jpg'
---

