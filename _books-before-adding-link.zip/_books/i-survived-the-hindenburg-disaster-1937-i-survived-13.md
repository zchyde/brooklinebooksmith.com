---
title: 'I Survived the Hindenburg Disaster, 1937 (I Survived #13)'
isbn: '9780545658508'
binding: Hardcover
image_path: 'https://images.booksense.com/images/508/658/9780545658508.jpg'
---


