---
title: The Tiger Rising
isbn: '9780763680879'
binding: Hardcover
image_path: 'https://images.booksense.com/images/879/680/9780763680879.jpg'
---

