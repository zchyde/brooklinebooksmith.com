---
title: 'Big Nate: Revenge of the Cream Puffs'
isbn: '9781449462284'
binding: Paperback
image_path: 'https://images.booksense.com/images/284/462/9781449462284.jpg'
---


It's one, two, three strikes, you're out, as the Cream Puffs seek sweet revenge&nbsp;
<br>Here come the Cream Puffs Nate and his baseball team, saddled with the most embarrassing moniker in Little League history, want to show the world they re not just a bunch of cupcakes. But it won t be easy. Their opponents mock them. The local sports section misprints Nate's name THREE TIMES. And now, on the day of the big game, illness and injuries have the team facing a crushing defeat . . . unless the unlikeliest Cream Puff of all can come in from the bullpen and save the day.&nbsp;
<br>With a softhearted pitcher who channels his inner panda, a vengeful girlfriend who swings for the fences, and a healthy dose of Nate Wright mojo, the Cream Puffs just might have what it takes to stage an epic comeback. So grab a glove, smear on some eyeblack, and get in the game. You don t want to miss a single moment of "Revenge of the Cream Puffs"