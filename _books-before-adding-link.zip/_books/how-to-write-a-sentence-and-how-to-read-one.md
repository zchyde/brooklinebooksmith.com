---
title: 'How to Write a Sentence: And How to Read One'
isbn: '9780061840531'
binding: Hardcover
image_path: 'https://images.booksense.com/images/531/840/9780061840531.jpg'
---

