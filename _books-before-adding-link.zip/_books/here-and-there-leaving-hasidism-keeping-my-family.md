---
title: "Here and There: Leaving Hasidism, Keeping My Family"
isbn: "9780805243178"
image_path: "https://ecx.images-amazon.com/images/I/51mrhzpLCGL.jpg"
thumbnail_height: "500"
thumbnail_width: "334"
url: "https://www.amazon.com/Here-There-Leaving-Hasidism-Keeping/dp/0805243178"
---

