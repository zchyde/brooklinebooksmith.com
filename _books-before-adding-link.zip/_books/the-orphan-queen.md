---
title: The Orphan Queen
isbn: '9780062317384'
binding: Hardcover
image_path: 'https://images.booksense.com/images/384/317/9780062317384.jpg'
---


An epic fantasy filled with adventure, intrigue, and romance from Incarnate series author Jodi Meadows. This duology is perfect for fans of Graceling by Kristin Cashore, The Girl of Fire and Thorns by Rae Carson, and Shadow and Bone by Leigh Bardugo.

When Princess Wilhelmina was a child, the Indigo Kingdom invaded her homeland. Ten years later, Wil and the other noble children who escaped are ready to fight back and reclaim Wil's throne. To do so, Wil and her best friend, Melanie, infiltrate the Indigo Kingdom palace with hopes of gathering information that will help them succeed.

But Wil has a secret one that could change everything. Although magic has been illegal for a century, she knows her ability could help her save her kingdom. But magic creates wraith, and the deadly stuff is moving closer and destroying the land. And if the vigilante Black Knife catches her using magic, she may disappear like all the others. . . .