---
title: Bottomland
isbn: '9780802124715'
binding: Hardcover
image_path: 'https://images.booksense.com/images/715/124/9780802124715.jpg'
---


In the years following World War I, the Hess family settles on Iowa farmland hoping to escape anti-German sentiment. Two of their girls disappear as the U.S. marches towards World War II, and relationships both within and outside of the family suffer. Based loosely on an unearthed family secret, Hoover has written an atmospheric novel evocative of both a time and place.