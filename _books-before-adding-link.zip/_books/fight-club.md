---
title: Fight Club
isbn: '9780393327342'
binding:
image_path: 'https://images.booksense.com/images/342/327/9780393327342.jpg'
---


