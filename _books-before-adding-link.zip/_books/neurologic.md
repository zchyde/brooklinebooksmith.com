---
title: "Neurologic: The Brain's Hidden Rationale Behind Our Irrational Behavior"
isbn: '9780307908773'
binding: Hardcover
image_path: 'https://images.booksense.com/images/773/908/9780307908773.jpg'
---

