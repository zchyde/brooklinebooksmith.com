---
title: Moonglow
isbn: '9780062225559'
binding: Hardcover
image_path: 'https://images.booksense.com/images/559/225/9780062225559.jpg'
---


Following on the heels of hisNew York Timesbestselling novelTelegraph Avenue, Pulitzer Prize-winning author Michael Chabon delivers another literary masterpiece: a novel of truth and lies, family legends, and existential adventure and the forces that work to destroy us.

In 1989, fresh from the publication of his first novel, The Mysteries of Pittsburgh, Michael Chabon traveled to his mother's home in Oakland, California, to visit his terminally ill grandfather. Tongue loosened by powerful painkillers, memory stirred by the imminence of death, Chabon's grandfather shared recollections and told stories the younger man had never heard before, uncovering bits and pieces of a history long buried and forgotten. That dreamlike week of revelations forms the basis for the novel Moonglow, the latest feat of legerdemain from Pulitzer Prize-winning author Michael Chabon.

Moonglow unfolds as the deathbed confession of a man the narrator refers to only as my grandfather. It is a tale of madness, of war and adventure, of sex and marriage and desire, of existential doubt and model rocketry, of the shining aspirations and demonic underpinnings of American technological accomplishment at midcentury, and, above all, of the destructive impact and the creative power of keeping secrets and telling lies. It is a portrait of the difficult but passionate love between the narrator's grandfather and his grandmother, an enigmatic woman broken by her experience growing up in war-torn France. It is also a tour de force of speculative autobiography in which Chabon devises and reveals a secret history of his own imagination.

From the Jewish slums of prewar South Philadelphia to the invasion of Germany, from a Florida retirement village to the penal utopia of New York's Wallkill prison, from the heyday of the space program to the twilight of the American Century, the novel revisits an entire era through a single life and collapses a lifetime into a single week. A lie that tells the truth, a work of fictional nonfiction, an autobiography wrapped in a novel disguised as a memoir, Moonglow is Chabon at his most moving and inventive.