---
title: Britt-Marie Was Here
isbn: '9781501142536'
binding: Hardcover
image_path: 'https://images.booksense.com/images/536/142/9781501142536.jpg'
---


The bestselling author of" A Man Called Ove "and "My Grandmother Asked Me to Tell You She's Sorry" returns with an irresistible novel about finding love and second chances in the most unlikely of places.&nbsp;
<br>Britt-Marie can t stand mess. A disorganized cutlery drawer ranks high on her list of unforgivable sins. She begins her day at 6 a.m., because only lunatics wake up later than that. And she is not passive-aggressive. Not in the least. It's just that sometimes people interpret her helpful suggestions as criticisms, which is certainly not her intention. She is not one to judge others no matter how ill-mannered, unkempt, or morally suspect they might be.&nbsp;
<br>But hidden inside the socially awkward, fussy busybody is a woman who has more imagination, bigger dreams, and a warmer heart that anyone around her realizes.&nbsp;
<br>When Britt-Marie walks out on her cheating husband and has to fend for herself in the miserable backwater town of Borg of which the kindest thing one can say is that it has a road going through it she is more than a little unprepared. Employed as the caretaker of a soon-to-be demolished recreation center, the fastidious Britt-Marie has to cope with muddy floors, unruly children, and a (literal) rat for a roommate. She finds herself being drawn into the daily doings of her fellow citizens, an odd assortment of miscreants, drunkards, layabouts and a handsome local policeman whose romantic attentions to Britt-Marie are as unmistakable as they are unwanted. Most alarming of all, she's given the impossible task of leading the supremely untalented children's soccer team to victory. In this small town of big-hearted misfits, can Britt-Marie find a place where she truly belongs?&nbsp;