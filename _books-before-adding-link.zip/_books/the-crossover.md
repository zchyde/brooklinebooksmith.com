---
title: The Crossover
isbn: '9780544107717'
binding: Hardcover
image_path: 'https://images.booksense.com/images/717/107/9780544107717.jpg'
---


2015 Newbery Medal Winner 2015 Coretta Scott King Honor Award Winner""With a bolt of lightning on my kicks . . .The court is SIZZLING. My sweat is DRIZZLING. Stop all that quivering. Cuz tonight I m delivering, "" announces dread-locked, 12-year old Josh Bell. Heand his twin brother Jordanare awesome on thecourt. But Josh has more than basketball in his blood, he's got mad beats, too, that tell his family's story in verse, in this fast and furiousmiddle grade novel of family and brotherhood from Kwame Alexander.

Josh and Jordanmust come togrips with growing up on and off the court to realize breaking the rules comes at a terrible price, as their story's heart-stopping climax proves a game-changer for the entire family.