---
title: "Oh, the Places You'll Go!"
isbn: '9780679805274'
binding: Hardcover
image_path: 'https://images.booksense.com/images/274/805/9780679805274.jpg'
---


A perennial favorite, Dr. Seuss's wonderfully wise graduation speech is the perfect send-off for children starting out in the world, be they nursery school, high school, or college grads From soaring to high heights and seeing great sights to being left in a Lurch on a prickle-ly perch, Dr. Seuss addresses life's ups and downs with his trademark humorous verse and illustrations, while encouraging readers to find the success that lies within. In a starred review, "Booklist" notes: Seuss's message is simple but never sappy: life may be a Great Balancing Act, but through it all There's fun to be done.&nbsp;