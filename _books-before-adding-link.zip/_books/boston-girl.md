---
title: Boston Girl
isbn: '9781439199367'
binding: Paperback
image_path: 'https://images.booksense.com/images/367/199/9781439199367.jpg'
---
