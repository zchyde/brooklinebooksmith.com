---
title: The Miniature World of Marvin and James
isbn: '9781250069580'
binding: Hardcover
image_path: 'https://images.booksense.com/images/580/069/9781250069580.jpg'
---

