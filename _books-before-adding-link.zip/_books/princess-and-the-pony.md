---
title: The Princess and the Pony
isbn: '9780545637084'
binding: Hardcover
image_path: 'https://images.booksense.com/images/084/637/9780545637084.jpg'
---

