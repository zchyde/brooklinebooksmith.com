---
title: 'Diary of a Wimpy Kid: Old School'
isbn: '9781419717017'
binding: Hardcover
image_path: 'https://images.booksense.com/images/017/717/9781419717017.jpg'
---

