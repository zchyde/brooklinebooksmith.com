---
title: The Lake House
isbn: '9781451649321'
binding: Hardcover
image_path: 'https://images.booksense.com/images/321/649/9781451649321.jpg'
---

