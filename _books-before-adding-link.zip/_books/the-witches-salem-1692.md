---
title: 'The Witches: Salem, 1692'
isbn: '9780316200608'
binding: Hardcover
image_path: 'https://images.booksense.com/images/608/200/9780316200608.jpg'
---

