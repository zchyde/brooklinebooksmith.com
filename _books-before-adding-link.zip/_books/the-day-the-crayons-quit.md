---
title: The Day the Crayons Quit
isbn: '9780399255373'
binding: Hardcover
image_path: 'https://images.booksense.com/images/373/255/9780399255373.jpg'
---

