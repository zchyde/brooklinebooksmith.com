---
title: "Colorless Tsukuru Tazaki and His Years of Pilgrimage"
isbn: "9780804170123"
image_path: "https://ecx.images-amazon.com/images/I/510iAdsKYdL.jpg"
thumbnail_height: "500"
thumbnail_width: "324"
url: "https://www.amazon.com/Colorless-Tsukuru-Tazaki-Years-Pilgrimage/dp/0804170126/ref=sr_1_4?s=books&amp;ie=UTF8&amp;qid=1444430869&amp;sr=1-4&amp;keywords=haruki+murakami"
---
