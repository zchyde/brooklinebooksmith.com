---
title: 'Citizen: An American Lyric'
isbn: '9781555976903'
binding: Paperback
image_path: 'https://images.booksense.com/images/903/976/9781555976903.jpg'
---

