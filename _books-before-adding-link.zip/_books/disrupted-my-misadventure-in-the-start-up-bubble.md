---
title: 'Disrupted: My Misadventure in the Start-Up Bubble'
isbn: '9780316306089'
binding: Hardcover
image_path: 'https://images.booksense.com/images/089/306/9780316306089.jpg'
---


