---
title: Beauty Is a Wound
isbn: '9780811223638'
binding:
image_path: 'https://images.booksense.com/images/638/223/9780811223638.jpg'
---


