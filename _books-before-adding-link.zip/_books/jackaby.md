---
title: Jackaby
isbn: '9781616205461'
binding: Hardcover
image_path: 'https://images.booksense.com/images/461/205/9781616205461.jpg'
---

