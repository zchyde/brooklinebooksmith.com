---
title: The Story of a New Name
isbn: '9781609451349'
binding: Paperback
image_path: 'https://images.booksense.com/images/349/451/9781609451349.jpg'
---

