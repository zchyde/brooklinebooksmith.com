---
title: "Savage Lane"
isbn: "9781940610641"
image_path: "https://ecx.images-amazon.com/images/I/51fMIINcy-L.jpg"
thumbnail_height: "500"
thumbnail_width: "319"
url: "https://www.amazon.com/Savage-Lane-Jason-Starr/dp/1940610648/ref=sr_1_1?s=books&amp;ie=UTF8&amp;qid=1445873474&amp;sr=1-1&amp;keywords=9781940610641"
---
