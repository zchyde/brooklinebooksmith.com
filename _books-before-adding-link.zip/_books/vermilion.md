---
title: Vermilion
isbn: '9781939905086'
binding:
image_path: 'https://images.booksense.com/images/086/905/9781939905086.jpg'
---


