---
title: Glass Sword
isbn: '9780062310668'
binding: Hardcover
image_path: 'https://images.booksense.com/images/668/310/9780062310668.jpg'
---

