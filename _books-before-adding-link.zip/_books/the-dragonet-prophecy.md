---
title: The Dragonet Prophecy
isbn: '9780545349239'
binding: Paperback
image_path: 'https://images.booksense.com/images/239/349/9780545349239.jpg'
---


The seven dragon tribes have been at war for generations, locked in an endless battle over an ancient, lost treasure. A secret movement called the Talons of Peace is determined to bring an end to the fighting, with the help of a prophecyNa foretelling that calls for great sacrifice.