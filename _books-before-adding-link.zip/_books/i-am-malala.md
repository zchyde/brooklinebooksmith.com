---
title: 'I Am Malala: The Girl Who Stood Up for Education and Was Shot by the Taliban'
isbn: '9780316322423'
binding: Hardcover
image_path: 'https://images.booksense.com/images/423/322/9780316322423.jpg'
---

