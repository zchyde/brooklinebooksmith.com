---
title: The Future Tense of Joy
isbn: '9781580055697'
binding:
image_path: 'https://images.booksense.com/images/697/055/9781580055697.jpg'
---


