---
title: A New Class
isbn: '9780545875738'
binding:
image_path: 'https://images.booksense.com/images/738/875/9780545875738.jpg'
---


