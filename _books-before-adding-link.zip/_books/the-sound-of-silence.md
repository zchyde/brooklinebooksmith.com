---
title: The Sound of Silence
isbn: '9780316203371'
binding:
image_path: 'https://images.booksense.com/images/371/203/9780316203371.jpg'
---


