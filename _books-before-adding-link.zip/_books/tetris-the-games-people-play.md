---
title: 'Tetris: The Games People Play'
isbn: '9781626723153'
binding: Paperback
image_path: 'https://images.booksense.com/images/153/723/9781626723153.jpg'
---


