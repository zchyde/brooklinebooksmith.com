---
title: The Wednesday Wars
isbn: '9780547237602'
binding: Paperback
image_path: 'https://images.booksense.com/images/602/237/9780547237602.jpg'
---


