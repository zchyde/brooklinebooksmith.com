---
title: "The Clasp"
isbn: "9780374124410"
image_path: "https://ecx.images-amazon.com/images/I/51tXw-w7QKL.jpg"
thumbnail_height: "500"
thumbnail_width: "331"
url: "https://www.amazon.com/The-Clasp-Novel-Sloane-Crosley/dp/0374124418"
---



