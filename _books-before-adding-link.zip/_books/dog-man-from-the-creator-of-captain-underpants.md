---
title: 'Dog Man: From the Creator of Captain Underpants'
isbn: '9780545581608'
binding: Hardcover
image_path: 'https://images.booksense.com/images/608/581/9780545581608.jpg'
---


New from the creator of Captain Underpants, it's Dog Man, the crime-biting canine who is part dog, part man, and ALL HERO&nbsp;
<br>George and Harold have created a new hero who digs into deception, claws after crooks, and rolls over robbers. When Greg the police dog and his cop companion are injured on the job, a life-saving surgery changes the course of history, and Dog Man is born. With the head of a dog and the body of a human, this heroic hound has a real nose for justice. But can he resist the call of the wild to answer the call of duty?