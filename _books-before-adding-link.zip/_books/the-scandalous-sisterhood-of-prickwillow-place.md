---
title: The Scandalous Sisterhood of Prickwillow Place
isbn: '9781250073396'
binding: Paperback
image_path: 'https://images.booksense.com/images/396/073/9781250073396.jpg'
---


There's a murderer on the loose but that doesn't stop the girls of St. Etheldreda's from attempting to hide the death of their headmistress in this rollicking farce.&nbsp;
<br>The students of St. Etheldreda's School for Girls face a bothersome dilemma. Their irascible headmistress, Mrs. Plackett, and her surly brother, Mr. Godding, have been most inconveniently poisoned at Sunday dinner. Now the school will almost certainly be closed and the girls sent home unless these seven very proper young ladies can hide the murders and convince their neighbors that nothing is wrong.