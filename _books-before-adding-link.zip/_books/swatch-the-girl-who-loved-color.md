---
title: 'Swatch: The Girl Who Loved Color'
isbn: '9780062366382'
binding: Hardcover
image_path: 'https://images.booksense.com/images/382/366/9780062366382.jpg'
---


A vibrant picture book featuring an irrepressible new character perfect for fans of The Dot and Beautiful Oops from acclaimed illustrator Julia Denos.

In a place where color ran wild, there lived a girl who was wilder still. Her name was Swatch, and color was her passion. From brave green to in-between gray to rumble-tumble pink . . . Swatch wanted to collect them all. But colors don t always like to be tamed. . . .

This is an exuberant celebration of all the beauty and color that make up our lives.