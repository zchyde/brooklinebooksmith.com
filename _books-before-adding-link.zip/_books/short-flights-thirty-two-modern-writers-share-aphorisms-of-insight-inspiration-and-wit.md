---
title: 'Short Flights: Thirty-Two Modern Writers Share Aphorisms of Insight, Inspiration, and Wit'
isbn: '9781936182886'
binding: Paperback
image_path: 'https://images.booksense.com/images/886/182/9781936182886.jpg'
---

