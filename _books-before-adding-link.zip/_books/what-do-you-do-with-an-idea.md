---
title: What Do You Do with an Idea?
isbn: '9781938298073'
binding: Hardcover
image_path: 'https://images.booksense.com/images/073/298/9781938298073.jpg'
---


Kobi Yamada is the creator of many inspiring gift books and ideas as well as the president of Compendium, a company of amazing people doing amazing things. He happily lives with the love of his life and their two super fun kids in the land of flying salmon where he gets to believe in his ideas all day long. He thinks he just might be the luckiest person on the planet.