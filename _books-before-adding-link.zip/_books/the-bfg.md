---
title: The BFG
isbn: '9780142410387'
binding:
image_path: 'https://images.booksense.com/images/387/410/9780142410387.jpg'
---


