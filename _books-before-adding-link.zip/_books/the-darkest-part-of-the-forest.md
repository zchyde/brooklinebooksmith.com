---
title: The Darkest Part of the Forest
isbn: '9780316213073'
binding: Hardcover
image_path: 'https://images.booksense.com/images/073/213/9780316213073.jpg'
---


"In the woods is a glass coffin. It rests on the ground, and in it sleeps a boy with horns on his head and ears as pointed as knives...."
Hazel and her brother, Ben, live in Fairfold, where humans and the Folk exist side by side. Tourists drive in to see the lush wonders of Faerie and, most wonderful of all, the horned boy. But visitors fail to see the danger.
Since they were children, Hazel and Ben have been telling each other stories about the boy in the glass coffin, that he is a prince and they are valiant knights, pretending their prince would be different from the other faeries, the ones who made cruel bargains, lurked in the shadows of trees, and doomed tourists. But as Hazel grows up, she puts aside those stories. Hazel knows the horned boy will never wake.
Until one day, he does....
As the world turns upside down, Hazel has to become the knight she once pretended to be. But as she's swept up in new love, with shifting loyalties and the fresh sting of betrayal, will it be enough?
"The Darkest Part of the Forest," is the bestselling author Holly Black's triumphant return to the opulent, enchanting faerie tales that launched her YA career.