---
title: "Kristy's Great Idea:"
isbn: '9780545813877'
binding: Paperback
image_path: 'https://images.booksense.com/images/877/813/9780545813877.jpg'
---


Kristy, Mary Anne, Claudia, and Stacey are best friends and founding members of The Baby-sitters Club. Whatever comes up -- cranky toddlers, huge dogs, scary neighbors, prank calls -- you can count on them to save the day. Baby-sitting isn't always easy, and neither is dealing with strict parents, new families, fashion emergencies, and mysterious secrets. But no matter what, the BSC have what they need most: friendship.&nbsp;
<br>Raina Telgemeier, using the signature style featured in her acclaimed graphic novels "Smile" and "Sisters," perfectly captures all the drama and humor of the original novel.