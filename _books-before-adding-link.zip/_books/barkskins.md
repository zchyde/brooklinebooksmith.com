---
title: Barkskins
isbn: '9780743288781'
binding:
image_path: 'https://images.booksense.com/images/781/288/9780743288781.jpg'
---


