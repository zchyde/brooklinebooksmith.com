---
title: 'Garth Williams, American Illustrator: A Life'
isbn: '9780825307959'
binding:
image_path: 'https://images.booksense.com/images/959/307/9780825307959.jpg'
---


