---
title: "The Mark and the Void: A Novel"
isbn: "9780865477551"
image_path: "https://ecx.images-amazon.com/images/I/414iVLHAtVL.jpg"
thumbnail_height: "500"
thumbnail_width: "333"
url: "https://www.amazon.com/The-Mark-Void-A-Novel/dp/0865477558"
---

