---
title: Jedi Academy
isbn: '9780545505178'
binding: Hardcover
image_path: 'https://images.booksense.com/images/178/505/9780545505178.jpg'
---


This incredible, original story from a "New York Times"-bestselling author/illustrator captures all of the humor, awkwardness, fun, and frustrations of middle schoolNall told through one boy's comics, journal entries, letters, doodles, and newspaper clippings. Illustrations.