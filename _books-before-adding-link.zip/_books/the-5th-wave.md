---
title: The 5th Wave
isbn: '9780142425831'
binding: Hardcover
image_path: 'https://images.booksense.com/images/831/425/9780142425831.jpg'
---

