---
title: 'Stories from the Shadows: Reflections of a Street Doctor'
isbn: '9780692412343'
binding: Hardcover
image_path: /uploads/cover-stories-from-the-shadows.jpg
---

