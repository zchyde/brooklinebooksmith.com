---
title: 'F*ck Feelings: One Shrink&#39;s Practical Advice for Managing All Life&#39;s Impossible Problems'
isbn: '9781476789996'
image_path: 'https://images.booksense.com/images/996/789/9781476789996.jpg'
thumbnail_height: '2092'
thumbnail_width: '2092'
url: 'https://www.goodreads.com/book/show/23492600-f-ck-feelings'
cover_image_path: /webhook-uploads/1443583259652_23492600._UY2092_SS2092_.jpg
---


