---
title: The Glass Sentence
isbn: '9780142423660'
binding: Paperback
image_path: 'https://images.booksense.com/images/660/423/9780142423660.jpg'
---


