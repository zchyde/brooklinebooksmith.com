---
title: Curious George Haunted Halloween
isbn: '9780544320796'
binding: Paperback
image_path: 'https://images.booksense.com/images/796/320/9780544320796.jpg'
---


