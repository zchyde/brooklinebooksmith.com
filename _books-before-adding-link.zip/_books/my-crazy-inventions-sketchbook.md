---
title: 'My Crazy Inventions Sketchbook: 50 Awesome Drawing Activities for Young Inventors'
isbn: '9781780676111'
binding: Paperback
image_path: 'https://images.booksense.com/images/111/676/9781780676111.jpg'
---

