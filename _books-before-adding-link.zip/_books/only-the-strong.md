---
title: "Only the Strong"
isbn: "9781932841947"
image_path: "https://ecx.images-amazon.com/images/I/41qfFo9iZIL.jpg"
thumbnail_height: "500"
thumbnail_width: "333"
url: "https://www.amazon.com/Only-Strong-Jabari-Asim/dp/1932841946/ref=sr_1_1?s=books&amp;ie=UTF8&amp;qid=1445873379&amp;sr=1-1&amp;keywords=9781932841947"
---
