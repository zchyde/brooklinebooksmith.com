---
title: The Girl with the Lower Back Tattoo
isbn: '9781501139888'
binding: Hardcover
image_path: 'https://images.booksense.com/images/888/139/9781501139888.jpg'
---


