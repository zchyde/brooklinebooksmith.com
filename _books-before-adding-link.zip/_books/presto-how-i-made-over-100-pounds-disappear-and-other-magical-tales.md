---
title: 'Presto!: How I Made Over 100 Pounds Disappear and Other Magical Tales'
isbn: '9781501140181'
binding:
image_path: 'https://images.booksense.com/images/181/140/9781501140181.jpg'
---


