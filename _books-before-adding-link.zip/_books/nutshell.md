---
title: Nutshell
isbn: '9780385542074'
binding: Hardcover
image_path: 'https://images.booksense.com/images/074/542/9780385542074.jpg'
---


New from the bestselling author of Atonement and The Children Act&nbsp;
<br>Trudy has betrayed her husband, John. She's still in the marital home a dilapidated, priceless London townhouse but John's not there. Instead, she's with his brother, the profoundly banal Claude, and the two of them have a plan. But there is a witness to their plot: theinquisitive, nine-month-old resident of Trudy's womb.&nbsp;
<br>Told from a perspective unlike any other, Nutshellis a classic taleof murder and deceit from one of the world's master storytellers.