---
title: Hex
isbn: '9780765378804'
binding: Hardcover
image_path: 'https://images.booksense.com/images/804/378/9780765378804.jpg'
---


