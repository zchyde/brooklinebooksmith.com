---
title: Americanah
isbn: '9780307455925'
binding: Paperback
image_path: 'https://images.booksense.com/images/925/455/9780307455925.jpg'
---

