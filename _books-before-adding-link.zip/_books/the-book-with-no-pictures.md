---
title: The Book with No Pictures
isbn: '9780803741713'
binding: Hardcover
image_path: 'https://images.booksense.com/images/713/741/9780803741713.jpg'
---

