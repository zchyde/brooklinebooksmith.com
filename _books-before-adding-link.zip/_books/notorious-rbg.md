---
title: 'Notorious RBG: The Life and Times of Ruth Bader Ginsburg'
isbn: '9780062415837'
binding: Hardcover
image_path: 'https://images.booksense.com/images/837/415/9780062415837.jpg'
---

Irin Carmon is a national reporter at MSNBC.

Shana Knizhnik is a recent graduate of the New York University School of Law and the creator of the Notorious R.B.G. Tumblr.