---
title: 'Good Night, Gorilla'
isbn: '9780399230035'
binding: Hardcover
image_path: 'https://images.booksense.com/images/035/230/9780399230035.jpg'
---

