---
title: 'The Life-Changing Magic of Tidying Up: The Japanese Art of Decluttering and Organizing'
isbn: '9781607747307'
binding: Hardcover
image_path: 'https://images.booksense.com/images/307/747/9781607747307.jpg'
---

